import os, sys
###############
# Dede : Hair #
# Fors : Repo #
###############
try:
 print('')
 print('[0m=====================================================[0;91m')
 os.system('figlet AUTOMATIC')
 print('[0m=====================================================')
 print('[^_*] Penyusun Ilay Tamvan [[0;93mIlay[0m]') 
 print('[^_^] Repo Github Milik Si [[0;93mhnov7[0m]')
 print('''[0m====================================================
 [0;92m[[0m1[0;92m] [0mInstall[0;93m cCuaca
 [0;92m[[0m2[0;92m] [0mInstall[0;93m hnov7.github.io
 [0;92m[[0m3[0;92m] [0mInstall[0;93m inf0rm
 [0;92m[[0m4[0;92m] [0mInstall[0;93m inf0rms
 [0;92m[[0m5[0;92m] [0mInstall[0;93m mbf
 [0;92m[[0m6[0;92m] [0mInstall[0;93m Multibrutefacebook
 [0;92m[[0m7[0;92m] [0mInstall[0;93m paypal
 [0;92m[[0m8[0;92m] [0mInstall[0;93m warung
 [0;92m[[0m9[0;92m] [0mInstall[0;93m wpinject''')
 f=["https://github.com/hnov7/cCuaca.git", "https://github.com/hnov7/hnov7.github.io.git", "https://github.com/hnov7/inf0rm.git", "https://github.com/hnov7/inf0rms.git", "https://github.com/hnov7/mbf.git", "https://github.com/hnov7/Multibrutefacebook.git", "https://github.com/hnov7/paypal.git", "https://github.com/hnov7/warung.git", "https://github.com/hnov7/wpinject.git"]
 print('[0m=====================================================')
 Plh=input('[0;93m[><][0m Install Nomer : ')
 print('=====================================================')
 Y=f[Plh-1]
 if f !=[]:
   try:
     os.system('git clone '+Y)
     print('=====================================================')
     print('[><] Selesai Install (Cek Folder)')
     print('=====================================================')
     os.system('ls')
     print('=====================================================')
   except(ImportError):
     sys.exit()
 else:
   sys.exit()
except(IndexError):
  print('=====================================================')
  print('Nomer > [0;91m['+str(Plh-1)+'[0;91m] [0;93mTidak Ada [0;92m Blaa[0;91mBlaa[0mBlaa..[92m([0;96mCek Ulang[0;96)[0m)')
  print('=====================================================')
  sys.exit()